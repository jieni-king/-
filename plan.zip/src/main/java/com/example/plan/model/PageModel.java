package com.example.plan.model;

import lombok.Data;

import java.util.List;

@Data
public class PageModel<T> {
    private int pageSize;            //页大小
    private int pageIndex;           //当前页号
    private int totalPageCount;      //总页数
    private int record;              //记录总数
    private Integer nextPage;          //下一页
    private Integer prePage;           //上一页
    private List<T> list;              //信息

    public PageModel(List<T> list, int pageIndex, int totalPageCount){
        this.list=list;
        setPageIndex(pageIndex);
        this.totalPageCount=totalPageCount;
        this.record=list.size();
        this.pageSize=list.size();
    }
}
