package com.example.plan.model;

import com.example.plan.entity.WorkSummary;
import lombok.Data;

import java.text.SimpleDateFormat;
import java.util.Date;

@Data
public class SummaryModel {
    private Long id;
    private String summary;
    private Long employee_id;
    private String time;
    public SummaryModel(){}
    public SummaryModel(WorkSummary workSummary){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        this.id=workSummary.getId();
        this.employee_id=workSummary.getEmployee_id();
        this.summary=workSummary.getSummary();
        this.time=sdf.format(workSummary.getTime());
    }
}
