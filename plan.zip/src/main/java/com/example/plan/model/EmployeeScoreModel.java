package com.example.plan.model;

import lombok.Data;

import java.util.List;

@Data
public class EmployeeScoreModel {
    private Integer employeeId;
    private String employeeName;
    private Float planScore;
    private List<SummaryScoreModel> summaryScore;
    private String time;
    private List<EvaluateModel> list;
}
