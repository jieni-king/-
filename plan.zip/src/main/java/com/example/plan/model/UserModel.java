package com.example.plan.model;


import com.example.plan.entity.Role;
import com.example.plan.entity.Token;
import com.example.plan.entity.User;
import lombok.Data;

import java.util.List;

@Data
public class UserModel {

    private Long userId;

    private String username;

    private String token;

    private List<Role> roles;

    public UserModel(){}
    public UserModel(Long Id,String token,List<Role> roles) {
        this.userId = Id;
        this.token=token;
        this.roles=roles;
    }
    public UserModel(Long Id,String username,String token,List<Role> roles) {
        this.userId = Id;
        this.token=token;
        this.roles=roles;
        this.username=username;
    }

}
