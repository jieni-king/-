package com.example.plan.model;

import lombok.Data;

@Data
public class SummaryScoreModel {
    private String summary;
    private Float avg_score;
}
