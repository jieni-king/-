package com.example.plan.model;

import lombok.Data;

import java.util.Date;
@Data
public class PlanModel {
    private Long id;
    private String plan;
    private Long employee_id;
    private Integer score;
    private String time;
    private Integer type;
    private String typeName;
}
