package com.example.plan.model;

import com.example.plan.entity.Role;
import lombok.Data;

import java.util.List;

@Data
public class UserModelForManager {

    private int userId;

    private String userName;

    private List<Role> roles;

    private String roleName;
    public UserModelForManager(){
    }
    public void add(){
        roleName="";
        for (int i=0;i<roles.size();i++){
            roleName+=this.roles.get(i).getRole()+" ";
        }
    }
}
