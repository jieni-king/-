package com.example.plan.model;

import lombok.Data;

@Data
public class EvaluateModel {
    private String bossName;
    private String comment;
    private String time;
}
