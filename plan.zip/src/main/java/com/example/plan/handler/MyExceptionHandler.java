package com.example.plan.handler;

import com.example.plan.model.BaseResult;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authz.AuthorizationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * 全局异常处理器
 */
@RestControllerAdvice
public class MyExceptionHandler {

    @ExceptionHandler(value = AuthorizationException.class)
    public BaseResult<String> handleException(AuthorizationException e) {
        //e.printStackTrace();
        BaseResult<String> result = new BaseResult<>();
        //获取错误中中括号的内容
        String message = e.getMessage();
        try {
            String msg=message.substring(message.indexOf("[")+1,message.indexOf("]"));
        //判断是角色错误还是权限错误
        if (message.contains("role")) {
            result.construct( "对不起，您没有" + msg + "角色",false,null);
        } else if (message.contains("permission")) {
            result.construct( "对不起，您没有" + msg + "权限",false,null);
        } else {
            result.construct( "对不起，您的权限有误",false,null);
        }
        }catch (Exception e1){
            result.construct( "对不起，您的权限有误",false,null);
            e1.printStackTrace();
        }
        return result;
    }

}
