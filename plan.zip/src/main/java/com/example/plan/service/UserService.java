package com.example.plan.service;

import com.example.plan.config.TokenGenerator;
import com.example.plan.dao.UserDao;
import com.example.plan.entity.Token;
import com.example.plan.entity.User;
import com.example.plan.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class UserService {

    //12小时后过期
    private final static int EXPIRE = 3600 * 12;

    @Autowired
    private UserDao userDao;

    @Transactional
    public void userLogin(User user, BaseResult<UserModel> baseResult){

        User temp_user=userDao.selectOneByName(user.getName());
        if (temp_user==null){
            baseResult.construct("用户不存在",false,null);
            return;
        }
        if (!temp_user.getPassword().equals(user.getPassword())){
            baseResult.construct("用户名或者密码错误",false,null);
            return;
        }
        //生成一个token
        String token = TokenGenerator.generateValue();
        //当前时间
        LocalDateTime now = LocalDateTime.now();
        //过期时间
        LocalDateTime expireTime = now.plusHours(EXPIRE);
        //判断是否生成过token
        Token tokenEntity = userDao.findTokenByUserId(temp_user.getId());
        if (tokenEntity == null) {
            tokenEntity = new Token();
            tokenEntity.setUserId(temp_user.getId());
            tokenEntity.setToken(token);
            tokenEntity.setUpdateTime(now);
            tokenEntity.setExpireTime(expireTime);
            //保存token
            userDao.addOneToken(tokenEntity);
        } else {
            tokenEntity.setToken(token);
            tokenEntity.setUpdateTime(now);
            tokenEntity.setExpireTime(expireTime);
            //更新token
            userDao.updateOneToken(tokenEntity);
        }
        UserModel userModel=new UserModel(temp_user.getId(),temp_user.getName(),token,userDao.getRoleByUser(temp_user.getId()));
        baseResult.construct("登陆成功",true,userModel);
        return;
    }

    @Transactional
    public void userRegister(User user,BaseResult<String> baseResult){

        User temp_user=userDao.selectOneByName(user.getName());
        if (temp_user!=null){
            baseResult.construct("用户已存在",false,null);
            return;
        }
        userDao.insertOne(user);
        baseResult.construct("注册成功",true,null);
    }

    @Transactional
    public void giveRole(BaseResult<String> baseResult,Long userId,Integer role){

        User temp_user=userDao.selectOneByUserId(userId);
        if (temp_user==null){
            baseResult.construct("用户不存在",false,null);
            return;
        }
        userDao.insertOneRoleWithUser(userId,role);
        baseResult.construct("赋权成功",true,null);
    }

    @Transactional
    public void deleteRole(BaseResult<String> baseResult,Long userId,Integer role){

        User temp_user=userDao.selectOneByUserId(userId);
        if (temp_user==null){
            baseResult.construct("用户不存在",false,null);
            return;
        }
        if (temp_user==null){
            baseResult.construct("用户不存在",false,null);
            return;
        }
        if (userDao.getOneRoleWithUser(userId,role)==null){
            baseResult.construct("该角色为拥有该权限！",false,null);
            return;
        }
        userDao.deleteOneRoleWithUser(userId,role);
        baseResult.construct("删除成功",true,null);
    }


    @Transactional
    public BaseResult<String> userLogout(BaseResult<String> baseResult, String token){
      if(userDao.deleteOneTokenByToken(token)==1){
          baseResult.construct("成功登出！",true,null);
          return baseResult;
      }
      baseResult.construct("登出异常！",false,null);
      return baseResult;
    }

    @Transactional
    public void findAllEmployeeByManager(BaseResult<PageModel<UserModelForManager>> baseResult,Integer page,Integer limit){
        List<UserModelForManager> list=new ArrayList<>();
        list=userDao.findEmployeeByManager();
        for (int i=0;i<list.size();i++){
            list.get(i).add();
        }
        PageModel<UserModelForManager> pageModel=new PageModel<>(list,page,userDao.countSunEmployee());
        if (list.size()==0){
            baseResult.construct("没有员工信息!",true,null);
            return ;
        }
        baseResult.construct("查询成功！",true,pageModel);
    }




}
