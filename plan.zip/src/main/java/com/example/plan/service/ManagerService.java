package com.example.plan.service;

import com.example.plan.dao.ManagerDao;
import com.example.plan.entity.Evaluate;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.BaseResult;
import com.example.plan.model.EmployeeScoreModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class ManagerService {
    @Autowired
    private ManagerDao managerDao;

    @Transactional
    public BaseResult<String> scoreOnePlan(BaseResult<String> baseResult,Long planId, int score){
        if(managerDao.updateOnePlanByScore(planId,score)==0){
            baseResult.construct("查不到该条工作计划，评分失败！",false,null);
            return baseResult;
        }
        baseResult.construct("评分成功！",true,null);
        return baseResult;
    }

    public BaseResult<String> addOneEvaluate(BaseResult<String> baseResult, Evaluate evaluate,Long employeeId,Float score){
        if (evaluate.getComment()==null){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        if (managerDao.insertOneEvaluate(evaluate)==0){
            baseResult.construct("插入失败，请重试！",false,null);
            return baseResult;
        }
        //找到该员工当前月中所有summaryId
        List<Integer> list=managerDao.getSummaryIdListByTime(employeeId,evaluate.getTime());
        System.out.println(list);
        for (int i=0;i<list.size();i++){
            managerDao.insertOneEvaluateIdAndSummaryId(evaluate.getId(),list.get(i),score);
        }
        baseResult.construct("增加成功!",true,null);
        return baseResult;
    }

    public BaseResult<String> deleteOneEvaluate(BaseResult<String> baseResult,Long evaluateId){
        if (managerDao.deleteOneEvaluateByEvaluateId(evaluateId)==0){
            baseResult.construct("没有找到符合条件的计划，删除失败！",false,null);
            return baseResult;
        }
        baseResult.construct("删除成功！",true,null);
        return baseResult;
    }

    @Transactional
    public void getMonthData(BaseResult<EmployeeScoreModel> baseResult, Long employeeId, Date time){
        EmployeeScoreModel employeeScoreModel=new EmployeeScoreModel();
        employeeScoreModel=managerDao.getEmployeeScoreModel(employeeId,time);
        System.out.println(employeeScoreModel.toString());
        baseResult.construct("查询成功",true,employeeScoreModel);
    }





}
