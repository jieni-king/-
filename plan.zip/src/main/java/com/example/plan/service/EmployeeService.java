package com.example.plan.service;

import com.example.plan.dao.EmployeeDao;
import com.example.plan.entity.Evaluate;
import com.example.plan.entity.WorkPlan;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.BaseResult;
import com.example.plan.model.PageModel;
import com.example.plan.model.PlanModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeDao employeeDao;

    public void addOneWorkPlan(BaseResult<String> baseResult,WorkPlan plan){
        if (plan.getPlan()==null){
            baseResult.construct("内容不能为空！",false,null);
            return ;
        }
        if (employeeDao.insertOneWorkPlan(plan)==0){
            baseResult.construct("删除失败，请重试！",false,null);
            return ;
        }        baseResult.construct("增加成功!",true,null);
        return ;
    }

    public void updateOneWorkPlan(BaseResult<String> baseResult,WorkPlan plan){
        if (plan.getPlan()==null){
            baseResult.construct("内容不能为空！",false,null);
            return ;
        }
        //该工作计划已经被评分过了
        if (employeeDao.findWorkPlanByPlanId(plan.getId()).getScore()>=0){
            baseResult.construct("该计划已经被评分过了,不能更改！",false,null);
            return ;
        }
        if (employeeDao.updateOnePlan(plan)==0){
            baseResult.construct("删除失败，请重试！",false,null);
            return ;
        }
        baseResult.construct("增加成功!",true,null);
        return ;
    }

    public void updateOneWorkSummary(BaseResult<String> baseResult,WorkSummary summary){
        if (summary.getSummary()==null){
            baseResult.construct("内容不能为空！",false,null);
            return ;
        }
        if (employeeDao.updateOneSummary(summary)==0){
            baseResult.construct("更新失败，请重试！",false,null);
            return ;
        }
        baseResult.construct("增加成功!",true,null);
        return ;
    }

    public void findPlan(BaseResult<List<WorkPlan>> baseResult,Long userId,String time,Integer type){
        List<WorkPlan> workPlans=new ArrayList<>();
        workPlans=employeeDao.findPlanByEmployeeId(userId,time,type);
        if (workPlans.size()==0){
            baseResult.construct("空空的，什么都没有！",true,null);
            return ;
        }
        baseResult.construct("查询成功！",true,workPlans);
        return ;
    }


    public void findPlanByPage(BaseResult<PageModel<PlanModel>> baseResult, Long userId,
                                                                String time, Integer type,Integer page, Integer limit){
        if (page<=0){
            baseResult.construct("页号输入不合法,请重新输入！",false,null);
            return;
        }
        List<PlanModel> workPlans=new ArrayList<>();
        workPlans=employeeDao.selectPlanListByPage(userId,time,type,(page-1)*limit,limit,userId);
        System.out.println(workPlans);
        PageModel<PlanModel> pageModels=new PageModel<PlanModel>(workPlans,page,employeeDao.countSunPlan(userId));
        if (workPlans.size()==0){
            baseResult.construct("当前页无数据",true,pageModels);
            return;
        }
        baseResult.construct("查询成功",true,pageModels);
    }

    public void findSummaryByPage(BaseResult<PageModel<WorkSummary>> baseResult, Long userId,
                               String time,Integer page, Integer limit){
        if (page<=0){
            baseResult.construct("页号输入不合法,请重新输入！",false,null);
            return;
        }
        List<WorkSummary> workSummaries=new ArrayList<>();
        workSummaries=employeeDao.selectSummaryListByPage(userId,time,(page-1)*limit,limit,userId);
        PageModel<WorkSummary> pageModels=new PageModel<WorkSummary>(workSummaries,page,employeeDao.countSunSummary(userId));
        if (workSummaries.size()==0){
            baseResult.construct("无数据",true,pageModels);
            return;
        }
        baseResult.construct("查询成功",true,pageModels);
    }

    public void findSummary(BaseResult<List<WorkSummary>> baseResult,Long userId,String time){
        List<WorkSummary> workSummarys=new ArrayList<>();
        workSummarys=employeeDao.findSummaryByEmployeeId(userId,time);
        if (workSummarys.size()==0){
            baseResult.construct("空空的，什么都没有！",true,null);
            return ;
        }
        baseResult.construct("查询成功！",true,workSummarys);
        return ;
    }

    public void findEvaluateByEmployeeId(BaseResult<List<Evaluate>> baseResult, Long userId, String time){
        List<Evaluate> evaluates=new ArrayList<>();
        evaluates=employeeDao.findEvaluateByEmployeeId(userId,time);
        if (evaluates.size()==0){
            baseResult.construct("空空的，什么都没有！",true,null);
            return ;
        }
        baseResult.construct("查询成功！",true,evaluates);
        return ;
    }

    public void deleteOnePlan(BaseResult<String> baseResult,Long workPlanId){
        //该工作计划已经被评分过了
        if (employeeDao.findWorkPlanByPlanId(workPlanId).getScore()>=0){
            baseResult.construct("该计划已经被评分过了,不能删除！",false,null);
            return ;
        }
        if (employeeDao.deleteOnePlanByWorkPlanId(workPlanId)==0){
            baseResult.construct("没有找到符合条件的计划，删除失败！",false,null);
            return;
        }
        baseResult.construct("删除成功！",true,null);
        return;
    }

    public void deleteOneSummary(BaseResult<String> baseResult,Long workSummaryId){
        if (employeeDao.deleteOneSummaryByWorkSummaryId(workSummaryId)==0){
            baseResult.construct("没有找到符合条件的计划，删除失败！",false,null);
            return;
        }
        baseResult.construct("删除成功！",true,null);
        return ;
    }


    public void addOneSummary(BaseResult<String> baseResult, WorkSummary summary){
        if (summary.getSummary()==null){
            baseResult.construct("内容不能为空！",false,null);
            return ;
        }
        if (employeeDao.insertOneWorkSummary(summary)==0){
            baseResult.construct("插入失败，请重试！",false,null);
            return ;
        }
        baseResult.construct("增加成功!",true,null);
        return ;
    }

}
