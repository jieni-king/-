package com.example.plan.controller;


import com.example.plan.entity.User;
import com.example.plan.model.BaseResult;
import com.example.plan.model.UserModel;
import com.example.plan.service.UserService;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/user")
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/login")
    @ResponseBody
    public BaseResult<UserModel> userlogin(@RequestParam(value = "username") String username,
                                           @RequestParam(value="password") String password){
        BaseResult<UserModel> baseResult=new BaseResult<UserModel>();
        if (StringUtils.isEmpty(username)){
            baseResult.construct("用户名为空",false,null);
            return baseResult;
        }
        if (StringUtils.isEmpty(password)){
            baseResult.construct("密码为空！",false,null);
            return baseResult;
        }
        User user=new User(username,password);
        userService.userLogin(user,baseResult);
        return baseResult;
    }

    @RequestMapping(value = "/register")
    @ResponseBody
    public BaseResult<String> userRegister(@RequestParam(value = "username") String username,
                                              @RequestParam(value="password") String password){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(username)){
            baseResult.construct("用户名为空！",false,null);
            return baseResult;
        }
        if (StringUtils.isEmpty(password)){
            baseResult.construct("密码为空！",false,null);
            return baseResult;
        }
        User user=new User(username,password);
        userService.userRegister(user,baseResult);
        return baseResult;
    }

    @RequiresPermissions(value = {"captain"})
    @RequestMapping(value = "/giveRole")
    @ResponseBody
    public BaseResult<String> giveRole(@RequestParam(value = "userId") Long userId,
                                              @RequestParam(value="roleId") Integer roleId){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(userId)){
            baseResult.construct("用户为空！",false,null);
            return baseResult;
        }
        if (StringUtils.isEmpty(roleId)){
            baseResult.construct("role为空！",false,null);
            return baseResult;
        }
        userService.giveRole(baseResult,userId,roleId);
        return baseResult;
    }

    @RequiresPermissions(value = {"captain"})
    @RequestMapping(value = "/deleteRole")
    @ResponseBody
    public BaseResult<String> deleteRole(@RequestParam(value = "userId") Long userId,
                                              @RequestParam(value="roleId") Integer roleId){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(userId)){
            baseResult.construct("用户为空！",false,null);
            return baseResult;
        }
        if (StringUtils.isEmpty(roleId)){
            baseResult.construct("role为空！",false,null);
            return baseResult;
        }
        userService.deleteRole(baseResult,userId,roleId);
        return baseResult;
    }

    @RequestMapping("/logout")
    @ResponseBody
    public BaseResult userLogout(@RequestParam("token")String token){
        BaseResult baseResult = new BaseResult<>();
        userService.userLogout(baseResult,token);
        return baseResult;
    }
}
