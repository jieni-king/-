package com.example.plan.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
    @RequestMapping("login")
    public String tologin(){
        return "login.html";
    }

}
