package com.example.plan.controller;

import com.example.plan.dao.UserDao;
import com.example.plan.entity.Evaluate;
import com.example.plan.entity.WorkPlan;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.BaseResult;
import com.example.plan.model.EmployeeScoreModel;
import com.example.plan.model.PageModel;
import com.example.plan.model.UserModelForManager;
import com.example.plan.service.ManagerService;
import com.example.plan.service.UserService;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("/manager")
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    @Autowired
    private UserService userService;

    @RequiresPermissions({"manager"})
    @RequestMapping("/score")
    public BaseResult<String> scoreOnePlan(@RequestParam(value = "planId") Long planId,
                                         @RequestParam(value = "score") Integer score){
        BaseResult<String> baseResult=new BaseResult<>();
        if (score>100||score<0){
            baseResult.construct("评分范围是0-100分，请在适当范围评分！",false,null);
            return baseResult;
        }
        managerService.scoreOnePlan(baseResult,planId,score);
        return baseResult;
    }

    @RequiresPermissions({"manager"})
    @RequestMapping("/insertOneEvaluate")
    public BaseResult<String> addOneSummary(@RequestParam(value = "comment") String comment,
                                            @RequestParam(value="userId") Long userId,
                                            @RequestParam(value="employeeId") Long employeeId,
                                            @RequestParam(value = "time") String time,
                                            @RequestParam(value = "score") Float score) {
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(comment)){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(time);
            Evaluate evaluate = new Evaluate(comment, userId, date);
            managerService.addOneEvaluate(baseResult, evaluate,employeeId,score);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    @RequiresPermissions({"manager"})
    @RequestMapping("/deleteOneEvaluate")
    public BaseResult<String> deleteOneBySummaryId(@RequestParam(value = "evaluateId") Long evaluateId){
        BaseResult<String> baseResult=new BaseResult<>();
        managerService.deleteOneEvaluate(baseResult,evaluateId);
        return baseResult;
    }

    @RequiresPermissions({"manager"})
    @RequestMapping("/findAllEmployee")
    public BaseResult<PageModel<UserModelForManager>> findEmployeeByManager(@RequestParam(value = "page") Integer page ,
                                                                            @RequestParam(value = "limit") Integer limit){
        BaseResult<PageModel<UserModelForManager>> baseResult=new BaseResult<>();
        userService.findAllEmployeeByManager(baseResult,page,limit);
        return baseResult;
    }
    /*
      查找所有员工某月的汇总
     */
    @RequiresPermissions(value = {"manager","employee"},logical= Logical.OR)
    @RequestMapping("/findOneEmployeeTotal")
    public BaseResult<EmployeeScoreModel> getMonthData(@RequestParam(value = "time",required = false,defaultValue = "0-0-0") String time,
                                                       @RequestParam(value = "employeeId") Long employeeId){
        BaseResult<EmployeeScoreModel> baseResult=new BaseResult<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date=new Date();
            if (time!="0-0-0"){
                date = sdf.parse(time);
            }
            managerService.getMonthData(baseResult,employeeId,date);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

}
