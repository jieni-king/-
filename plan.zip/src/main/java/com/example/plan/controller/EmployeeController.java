package com.example.plan.controller;
import com.example.plan.entity.Evaluate;
import com.example.plan.model.PageModel;
import com.example.plan.model.PlanModel;
import com.example.plan.service.EmployeeService;
import com.example.plan.entity.WorkPlan;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.BaseResult;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    /*
      type为0表示将所有类型的workplan全部找出
      time为空表示没有时间限制的查询
    */
    @RequiresPermissions({"employee"}) //没有的话 AuthorizationException
    @RequestMapping("/findPlan")
    public BaseResult<List<WorkPlan>> findPlanByEmployeeId(@RequestParam(value = "userId") Long userId,
                                                           @RequestParam(value = "time",defaultValue = "",required = false) String time,
                                                           @RequestParam(value= "type",defaultValue = "0",required = false) Integer type){
        BaseResult<List<WorkPlan>> baseResult =new BaseResult<>();
        employeeService.findPlan(baseResult,userId,time,type);
        return baseResult;
    }

    //获取某个员工某个月的所有的工作计划和当月的工作总结及其所获取的分数
    @RequiresPermissions({"employee"}) //没有的话 AuthorizationException
    @RequestMapping("/findPlanScoreByMonth")
    public BaseResult<List<WorkPlan>> findPlanScoreByMonth(@RequestParam(value = "userId") Long userId,
                                                           @RequestParam(value = "time") String time){
        BaseResult<List<WorkPlan>> baseResult =new BaseResult<>();
        return baseResult;
    }






    /*
     type为0表示将所有类型的workplan全部找出
     time为空表示没有时间限制的查询
   */
    @RequiresPermissions(value = {"employee", "manager"}, logical = Logical.OR) //没有的话 AuthorizationException
    @RequestMapping("/findPlanByPage")
    public BaseResult<PageModel<PlanModel>> findPlanByPage(@RequestParam(value = "page") Integer page ,
                                                @RequestParam(value = "limit") Integer limit,
                                                @RequestParam(value = "userId") Long userId,
                                                @RequestParam(value = "time",defaultValue = "0-0-0",required = false) String time,
                                                @RequestParam(value= "type",defaultValue = "0",required = false) Integer type){
        BaseResult<PageModel<PlanModel>> baseResult =new BaseResult<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(time);
            employeeService.findPlanByPage(baseResult,userId,time,type,page,limit);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    /*
     type为0表示将所有类型的workplan全部找出
     time为空表示没有时间限制的查询
   */
    @RequiresPermissions(value = {"employee", "manager"}, logical = Logical.OR) //没有的话 AuthorizationException
    @RequestMapping("/findSummaryByPage")
    public BaseResult<PageModel<WorkSummary>> findSummaryByPage(@RequestParam(value = "page") Integer page ,
                                                          @RequestParam(value = "limit") Integer limit,
                                                          @RequestParam(value = "userId") Long userId,
                                                          @RequestParam(value = "time",defaultValue = "0-0-0",required = false) String time){
        BaseResult<PageModel<WorkSummary>> baseResult =new BaseResult<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(time);
            employeeService.findSummaryByPage(baseResult,userId,time,page,limit);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/findSummary")
    public BaseResult<List<WorkSummary>> findSummaryByEmployeeId(@RequestParam(value = "userId") Long userId,
                                                           @RequestParam(value = "time",defaultValue = "",required = false) String time){
        BaseResult<List<WorkSummary>> baseResult =new BaseResult<>();
        employeeService.findSummary(baseResult,userId,time);
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/findEvaluateByEmployeeId")
    public BaseResult<List<Evaluate>> findEvaluateByEmployeeId(@RequestParam(value = "userId") Long userId,
                                                               @RequestParam(value = "time",defaultValue = "",required = false) String time){
        BaseResult<List<Evaluate>> baseResult =new BaseResult<>();
        employeeService.findEvaluateByEmployeeId(baseResult,userId,time);
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/insertOnePlan")
    public BaseResult<String> addOnePlan(@RequestParam(value = "plan",required = false,defaultValue = "请编辑") String plan,
                                         @RequestParam(value = "time",required = false,defaultValue = "0") String time,
                                         @RequestParam(value = "type",required = false,defaultValue = "1") Integer type,
                                         @RequestParam(value = "userId") Long userId){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(plan)){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date=new Date();
            if (time.equals("0")){
                date=new Date();
            }else {
                date = sdf.parse(time);
            }
            WorkPlan workPlan = new WorkPlan(type,plan,userId, date);
            employeeService.addOneWorkPlan(baseResult, workPlan);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/updateOnePlan")
    public BaseResult<String> updateOnePlan(@RequestParam(value = "planId") Long planId,
                                         @RequestParam(value = "plan",required = false,defaultValue = "请编辑") String plan,
                                         @RequestParam(value = "time",required = false,defaultValue = "0-0-0") String time,
                                         @RequestParam(value = "type",required = false,defaultValue = "重要") String typeName,
                                         @RequestParam(value = "userId") Long userId){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(plan)){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(time);
            System.out.println("?"+date);
            Integer type=1;
            switch (typeName){
                case "重要":
                    type=1;
                    break;
                    case "一般":
                    type=2;
                    break;
                    case "临时":
                    type=3;
                    break;
            }
            WorkPlan workPlan = new WorkPlan(planId,plan,type ,userId, date);
            employeeService.updateOneWorkPlan(baseResult, workPlan);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/updateOneSummary")
    public BaseResult<String> updateOneSummary(@RequestParam(value = "summaryId") Long summaryId,
                                            @RequestParam(value = "summary",required = false,defaultValue = "请编辑") String summary,
                                            @RequestParam(value = "time",required = false,defaultValue = "0-0-0") String time,
                                            @RequestParam(value = "userId") Long userId){
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(summary)){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = sdf.parse(time);
            WorkSummary workSummary = new WorkSummary(summaryId,summary,userId, date);
            employeeService.updateOneWorkSummary(baseResult, workSummary);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/deleteOnePlan")
    public BaseResult<String> deleteOneByPlanId(@RequestParam(value = "workPlanId") Long workPlanId){
        BaseResult<String> baseResult=new BaseResult<>();

        employeeService.deleteOnePlan(baseResult,workPlanId);
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/deleteOneSummary")
    public BaseResult<String> deleteOneBySummaryId(@RequestParam(value = "summaryId") Long workSummaryid){
        BaseResult<String> baseResult=new BaseResult<>();
        employeeService.deleteOneSummary(baseResult,workSummaryid);
        return baseResult;
    }

    @RequiresPermissions({"employee"})
    @RequestMapping("/insertOneSummary")
    public BaseResult<String> addOneSummary(@RequestParam(value = "summary",required = false,defaultValue = "请编辑") String summary,
                                         @RequestParam(value="userId") Long userId,
                                         @RequestParam(value = "time",required = false,defaultValue = "0") String time) {
        BaseResult<String> baseResult=new BaseResult<>();
        if (StringUtils.isEmpty(summary)){
            baseResult.construct("内容不能为空！",false,null);
            return baseResult;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date=new Date();
            if (time.equals("0")){
                date=new Date();
            }else {
                date = sdf.parse(time);
            }
            WorkSummary workSummary = new WorkSummary(summary, userId, date);
            employeeService.addOneSummary(baseResult, workSummary);
        }catch (ParseException e){
            baseResult.construct("插入失败，日期格式不对！",false,null);
        }
        return baseResult;
    }

}
