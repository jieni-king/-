package com.example.plan.dao;

import com.example.plan.entity.Evaluate;
import com.example.plan.entity.WorkPlan;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.PlanModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface EmployeeDao {
    List<WorkPlan> findPlanByEmployeeId(Long employeeId,String time,Integer type);

    Float findPlanScoreByTime(Long employeeId,String time);

    List<WorkSummary> findSummaryByEmployeeId(Long employeeId,String time);

    List<Evaluate> findEvaluateByEmployeeId(Long employeeId, String time);

    int deleteOnePlanByWorkPlanId(Long workPlanId);

    int deleteOneSummaryByWorkSummaryId(Long workSummaryId);

    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insertOneWorkPlan(WorkPlan plan);

    int updateOnePlan(WorkPlan plan);

    int updateOneSummary(WorkSummary summary);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    int insertOneWorkSummary(WorkSummary summary);

    int countSunPlan(Long userId);

    int countSunSummary(Long userId);

    List<PlanModel> selectPlanListByPage(Long employeeId, String time, Integer type, @Param("start")Integer start, @Param("end")Integer end, @Param("userId")Long UserId );

    List<WorkSummary> selectSummaryListByPage(Long employeeId,String time,@Param("start")Integer start, @Param("end")Integer end,@Param("userId")Long UserId );

    WorkPlan findWorkPlanByPlanId(long planId);

    WorkSummary findWorkSummaryBySummaryId(long summaryId);

}
