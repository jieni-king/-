package com.example.plan.dao;

import com.example.plan.entity.Evaluate;
import com.example.plan.entity.WorkSummary;
import com.example.plan.model.EmployeeScoreModel;
import com.example.plan.model.EvaluateModel;
import com.example.plan.model.SummaryScoreModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;

import javax.xml.crypto.Data;
import java.util.Date;
import java.util.List;

@Mapper
public interface ManagerDao {

    Long updateOnePlanByScore(Long planId,int score);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    int insertOneEvaluate(Evaluate evaluate);

    int insertOneEvaluateIdAndSummaryId(Long evaluateId,Integer summaryId,Float score);

    List<Integer> getSummaryIdListByTime(Long employeeId,Date time);

    int deleteOneEvaluateByEvaluateId(Long evaluateId);

    Float getPlanScore(Long employeeId,Date time);

    List<SummaryScoreModel> getSummaryScore(Long employeeId, Date time);

    List<EvaluateModel> getEvaluateModel(Long employeeId, Date time);

    EmployeeScoreModel getEmployeeScoreModel(Long employeeId,Date time);
}
