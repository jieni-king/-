package com.example.plan.dao;


import com.example.plan.entity.Role;
import com.example.plan.entity.Token;
import com.example.plan.entity.User;
import com.example.plan.model.UserModelForManager;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserDao {

    User selectOneByName(String name);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    void insertOne(User user);

    User selectOneByUserId(Long id);

    Token findTokenByUserId(Long userId);

    void addOneToken(Token token);

    void updateOneToken(Token token);

    Token findTokenByToken(String token);

    int deleteOneTokenByToken(String token);

    List<UserModelForManager> findEmployeeByManager();

    List<Role> getRoleByUser(Long userId);

    Integer insertOneRoleWithUser(Long userId,Integer roleId);

    Integer deleteOneRoleWithUser(Long userId,Integer roleId);

    Integer getOneRoleWithUser(Long userId,Integer roleId);

    int countSunEmployee();

}
