package com.example.plan.entity;

import lombok.Data;

import java.util.Date;

@Data
public class Evaluate {
    private Long id;
    private String comment;
    private Long boss_id;
    private Date time;

    public Evaluate(){}
    public Evaluate(String comment,Long boss_id,Date time){
        setBoss_id(boss_id);
        setComment(comment);
        setTime(time);
    }
}
