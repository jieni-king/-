package com.example.plan.entity;

import lombok.Data;

@Data
public class Role {
    private Integer roleId;
    private String role;
}
