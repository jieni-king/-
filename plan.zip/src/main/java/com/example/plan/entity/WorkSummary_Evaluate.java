package com.example.plan.entity;

import lombok.Data;
/*
  多对多
  一个周总结可以对应多个来自不同领导组长的月末评价
  领导和组长的月末评价是对应一个员工这个月的所有周总结
 */
@Data
public class WorkSummary_Evaluate {
    private Integer workSummaryId;
    private Integer evaluateId;
    private Float score;
}
