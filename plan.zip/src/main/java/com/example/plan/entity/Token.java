package com.example.plan.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Token {

    private Long userId;

    /**
     * token
     */
    private String token;

    /**
     * 过期时间
     */
    private LocalDateTime expireTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

}
