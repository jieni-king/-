package com.example.plan.entity;

import lombok.Data;

import java.util.Date;

@Data
public class WorkSummary {
    private Long id;
    private String summary;
    private Long employee_id;
    private Date time;
    public WorkSummary(){};
    public WorkSummary(String summary,Long employee_id,Date time){
        setEmployee_id(employee_id);
        setSummary(summary);
        setTime(time);
    }
    public WorkSummary(Long id,String summary,Long employee_id,Date time){
        setId(id);
        setEmployee_id(employee_id);
        setSummary(summary);
        setTime(time);
    }
}
