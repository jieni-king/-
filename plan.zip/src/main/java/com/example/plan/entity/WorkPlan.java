package com.example.plan.entity;

import lombok.Data;

import java.util.Date;

@Data
public class WorkPlan {
    private Long id;
    private String plan;
    private Long employee_id;
    private Integer score;
    private Date time;
    private Integer type;

    WorkPlan(){}
    public WorkPlan(Integer type,String plan,Long employee_id,Date time){
        setEmployee_id(employee_id);
        setPlan(plan);
        setTime(time);
        setScore(-1);
        this.type=type;
    }
    public WorkPlan(Long id,String plan,Integer type,Long employee_id,Date time){
        setId(id);
        setEmployee_id(employee_id);
        setPlan(plan);
        setTime(time);
        setScore(-1);
        this.type=type;
    }
}
