package com.example.plan.entity;

import lombok.Data;

import java.sql.Timestamp;
import java.util.Date;

@Data
public class User_Role {
    private Integer userId;
    private Integer roleId;
    //被赋予权限的时间
    private Date time;
}
