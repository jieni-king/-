package com.example.plan.entity;

import lombok.Data;

@Data
public class User {
    private Long id;
    private String name;
    private String password;
    private Integer bossId;

    public User (){};
    public User(String name, String password) {
        this.name=name;
        this.password=password;
    }
}
