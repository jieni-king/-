package com.example.plan.util;

import java.util.UUID;

public class Format {

    public static String IdGenerator(){
        //return "kokodaze";
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-", "");
    }
}
